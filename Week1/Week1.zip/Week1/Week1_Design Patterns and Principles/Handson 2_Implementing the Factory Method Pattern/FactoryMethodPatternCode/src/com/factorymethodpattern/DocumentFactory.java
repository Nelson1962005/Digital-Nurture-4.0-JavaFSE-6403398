package com.factorymethodpattern;

public abstract class DocumentFactory {
    public abstract Document createDocument();
}
