package com.factorymethodpattern;

public interface Document {
    void open();
}
